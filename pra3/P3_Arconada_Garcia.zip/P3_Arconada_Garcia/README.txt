Autores: Miguel Arconada Manteca
	 Mario Garc�a Pascual

Para este programa, la consideraci�n m�s importante que hemos tomado es que, en la segunda funci�n, cuando decodificamos el c�digo de producto (que son 5 caracteres), tenemos en cuenta al operar el n�mero cuando da overflow en un byte, y tenemos que aumentar DX manualmente.

Por lo dem�s, no hemos tomado ninguna decisi�n de dise�o